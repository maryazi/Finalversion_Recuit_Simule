module com.example.appinterface {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.appinterface to javafx.fxml;
    exports com.example.appinterface;
}