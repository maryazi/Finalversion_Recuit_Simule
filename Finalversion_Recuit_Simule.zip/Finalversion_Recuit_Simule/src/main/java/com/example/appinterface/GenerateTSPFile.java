package com.example.appinterface;

import java.io.*;
import java.util.Random;

public class GenerateTSPFile {

    public static void main(String[] args) {
        // Nombre de villes
        int n = 30;

        // Création d'un fichier
        File file = new File("distances_30_villes.txt");

        // Création d'un générateur de nombres aléatoires
        Random rand = new Random();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Génération d'une matrice de distances aléatoires
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j) {
                        writer.write("0 "); // La distance entre une ville et elle-même est 0
                    } else {
                        // Générer une distance aléatoire entre 1 et 100
                        writer.write(rand.nextInt(100) + 1 + " ");
                    }
                }
                writer.newLine(); // Passer à la ligne suivante
            }

            System.out.println("Fichier de distances généré avec succès : " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Erreur lors de la création du fichier : " + e.getMessage());
        }
    }
}
