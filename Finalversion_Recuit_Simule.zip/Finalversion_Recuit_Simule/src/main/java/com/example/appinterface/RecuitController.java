package com.example.appinterface;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class RecuitController implements Initializable {

    @FXML private ComboBox<String> choixProbleme;
    @FXML private TextArea resultatArea;
    @FXML private TextField poidsField;
    @FXML private TextField valeurField;
    @FXML private TextField capaciteField;
    @FXML private ListView<String> listeObjets;
    @FXML private VBox sacadosBox;
    @FXML private Button importerButton;
    @FXML private VBox chartContainer;
    @FXML private TextField tempInitialeField;
    @FXML private TextField tauxRefroidissementField;
    @FXML private TextField maxIterationsField;

    private LineChart<Number, Number> convergenceChart;
    private final List<Objet> objets = new ArrayList<>();
    private final TSP tsp = new TSP();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tempInitialeField.setText("1000");
        tauxRefroidissementField.setText("0.95");
        maxIterationsField.setText("10000");
        initializeChart();

        choixProbleme.setItems(FXCollections.observableArrayList(
                "Sac à dos", "Voyageur de commerce", "f(x) = x cos(3πx)"
        ));
        choixProbleme.getSelectionModel().selectFirst();
        choixProbleme.setOnAction(event -> onChoixProblemeChanged());
        onChoixProblemeChanged();
    }

    private void initializeChart() {
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Itération");
        yAxis.setLabel("Valeur");

        convergenceChart = new LineChart<>(xAxis, yAxis);
        convergenceChart.setTitle("Convergence de l'algorithme");
        convergenceChart.setPrefSize(500, 300);
        chartContainer.getChildren().add(convergenceChart);
    }

    private void updateChart(List<Integer> valeurs) {
        convergenceChart.getData().clear();

        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName("Valeur de la solution");

        for (int i = 0; i < valeurs.size(); i++) {
            series.getData().add(new XYChart.Data<>(i * 100, valeurs.get(i)));
        }

        convergenceChart.getData().add(series);
    }

    @FXML
    private void onChoixProblemeChanged() {
        String choix = choixProbleme.getValue();

        // Affichage des éléments spécifiques
        sacadosBox.setVisible("Sac à dos".equals(choix));
        importerButton.setVisible("Voyageur de commerce".equals(choix));
        chartContainer.setVisible("Sac à dos".equals(choix)); // cacher le graphe sauf pour sac à dos

        // Nettoyage des anciennes données
        resultatArea.clear();
        convergenceChart.getData().clear();

        if (!"Sac à dos".equals(choix)) {
            objets.clear();
            listeObjets.getItems().clear();
            capaciteField.clear();
            poidsField.clear();
            valeurField.clear();
        }
    }

    @FXML
    private void onRunClicked() {
        String choix = choixProbleme.getValue();
        if (choix == null) return;

        switch (choix) {
            case "Sac à dos":
                runSacADos();
                break;
            case "Voyageur de commerce":
                runTSP();
                break;
            case "f(x) = x cos(3πx)":
                runFonctionContinue();
                break;
        }
    }

    private void runSacADos() {
        try {
            int capacite = Integer.parseInt(capaciteField.getText());
            double tempInitiale = Double.parseDouble(tempInitialeField.getText());
            double tauxRefroidissement = Double.parseDouble(tauxRefroidissementField.getText());
            int maxIterations = Integer.parseInt(maxIterationsField.getText());

            if (capacite <= 0 || tempInitiale <= 0 || tauxRefroidissement <= 0 || maxIterations <= 0) {
                resultatArea.setText("⚠️ Tous les paramètres doivent être positifs.");
                return;
            }

            if (objets.isEmpty()) {
                resultatArea.setText("⚠️ Ajoutez au moins un objet.");
                return;
            }

            SacADos.ResultatRecuit result = SacADos.recuitSimule(
                    objets, capacite, tempInitiale, tauxRefroidissement, maxIterations);

            // Affichage des résultats
            StringBuilder res = new StringBuilder();
            res.append("=== Statistiques d'exécution ===\n");
            res.append(String.format("Itérations: %d\n", result.stats.iterations));
            res.append(String.format("Température initiale: %.2f\n", result.stats.temperatureInitiale));
            res.append(String.format("Température finale: %.2f\n", result.stats.temperatureFinale));
            res.append(String.format("Meilleure valeur trouvée: %d\n\n", result.stats.meilleureValeur));

            res.append("=== Objets choisis ===\n");
            int totalPoids = 0, totalValeur = 0;
            for (int i = 0; i < result.solution.length; i++) {
                if (result.solution[i]) {
                    Objet o = objets.get(i);
                    res.append(String.format("- Poids: %d, Valeur: %d\n", o.getPoids(), o.getValeur()));
                    totalPoids += o.getPoids();
                    totalValeur += o.getValeur();
                }
            }
            res.append(String.format("\nPoids total = %d / %d\n", totalPoids, capacite));
            res.append(String.format("Valeur totale = %d\n", totalValeur));

            resultatArea.setText(res.toString());

            // Mise à jour du graphique
            updateChart(result.stats.valeursIntermediaires);

        } catch (NumberFormatException e) {
            resultatArea.setText("❌ Paramètres invalides. Vérifiez les valeurs entrées.");
        }
    }

    private void runTSP() {
        if (tsp.getDistanceMatrix() != null) {
            int[] chemin = TSP.recuitSimule(tsp.getDistanceMatrixAsDouble());
            resultatArea.setText("Résultat TSP :\n" + Arrays.toString(chemin));
        } else {
            resultatArea.setText("⚠️ Veuillez importer un fichier de distances d'abord.");
        }
    }

    private void runFonctionContinue() {
        double x = FonctionContinue.recuitSimule(-2, 3);
        resultatArea.setText(String.format("x optimal = %.5f\nf(x) = %.5f", x, FonctionContinue.f(x)));
    }

    @FXML
    private void onAjouterObjetClicked() {
        try {
            int poids = Integer.parseInt(poidsField.getText());
            int valeur = Integer.parseInt(valeurField.getText());

            if (poids <= 0 || valeur <= 0) {
                resultatArea.setText("⚠️ Poids et valeur doivent être positifs.");
                return;
            }

            Objet obj = new Objet(poids, valeur);
            objets.add(obj);
            listeObjets.getItems().add("Poids: " + poids + ", Valeur: " + valeur);

            poidsField.clear();
            valeurField.clear();
        } catch (NumberFormatException e) {
            resultatArea.setText("❌ Entrée invalide. Entrez des nombres entiers.");
        }
    }

    @FXML
    private void onImporterClicked() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir un fichier de distances TSP");
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            try {
                tsp.loadDistanceMatrix(file);
                resultatArea.setText("✅ Fichier importé avec succès !");
            } catch (IOException e) {
                resultatArea.setText("❌ Erreur lors du chargement du fichier : " + e.getMessage());
            }
        }
    }
}