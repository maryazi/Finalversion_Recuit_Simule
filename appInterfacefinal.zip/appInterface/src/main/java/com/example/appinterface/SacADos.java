package com.example.appinterface;

import java.util.*;

public class SacADos {

    public static class ExecutionStats {
        public int iterations;
        public double temperatureInitiale;
        public double temperatureFinale;
        public int meilleureValeur;
        public List<boolean[]> solutionsIntermediaires;
        public List<Integer> valeursIntermediaires;

        public ExecutionStats() {
            solutionsIntermediaires = new ArrayList<>();
            valeursIntermediaires = new ArrayList<>();
        }
    }

    public static class ResultatRecuit {
        public boolean[] solution;
        public ExecutionStats stats;

        public ResultatRecuit(boolean[] solution, ExecutionStats stats) {
            this.solution = solution;
            this.stats = stats;
        }
    }

    public static ResultatRecuit recuitSimule(List<Objet> objets, int capacite,
                                              double temperatureInitiale,
                                              double tauxRefroidissement,
                                              int maxIterations) {
        Random rand = new Random();
        boolean[] solution = new boolean[objets.size()];
        ExecutionStats stats = new ExecutionStats();
        stats.temperatureInitiale = temperatureInitiale;

        // Solution initiale aléatoire valide
        for (int i = 0; i < objets.size(); i++) {
            solution[i] = rand.nextBoolean();
        }
        while (!estValide(solution, objets, capacite)) {
            int index = rand.nextInt(objets.size());
            solution[index] = false;
        }

        boolean[] meilleureSolution = solution.clone();
        stats.meilleureValeur = valeurTotale(solution, objets);
        double temperature = temperatureInitiale;

        for (int iter = 0; iter < maxIterations && temperature > 1; iter++) {
            boolean[] voisin = solution.clone();
            int index = rand.nextInt(objets.size());
            voisin[index] = !voisin[index];

            if (estValide(voisin, objets, capacite)) {
                int delta = valeurTotale(voisin, objets) - valeurTotale(solution, objets);

                if (delta > 0 || Math.exp(delta / temperature) > rand.nextDouble()) {
                    solution = voisin;
                    int valeurCourante = valeurTotale(solution, objets);

                    if (valeurCourante > stats.meilleureValeur) {
                        meilleureSolution = solution.clone();
                        stats.meilleureValeur = valeurCourante;
                    }

                    if (iter % 100 == 0) {
                        stats.solutionsIntermediaires.add(solution.clone());
                        stats.valeursIntermediaires.add(valeurCourante);
                    }
                }
            }

            temperature *= tauxRefroidissement;
            stats.iterations = iter;
        }

        stats.temperatureFinale = temperature;
        return new ResultatRecuit(meilleureSolution, stats);
    }

    private static boolean estValide(boolean[] sol, List<Objet> objets, int capacite) {
        int poids = 0;
        for (int i = 0; i < sol.length; i++) {
            if (sol[i]) poids += objets.get(i).getPoids();
        }
        return poids <= capacite;
    }

    public static int valeurTotale(boolean[] sol, List<Objet> objets) {
        int valeur = 0;
        for (int i = 0; i < sol.length; i++) {
            if (sol[i]) valeur += objets.get(i).getValeur();
        }
        return valeur;
    }

    public static List<Objet> solutionToObjets(boolean[] solution, List<Objet> objets) {
        List<Objet> result = new ArrayList<>();
        for (int i = 0; i < solution.length; i++) {
            if (solution[i]) {
                result.add(objets.get(i));
            }
        }
        return result;
    }
}