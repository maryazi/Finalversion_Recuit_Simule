package com.example.appinterface;

import java.util.Random;

public class FonctionContinue {

    public static double f(double x) {
        return x * Math.cos(3 * Math.PI * x);
    }

    public static double recuitSimule(double min, double max) {
        Random rand = new Random();
        double x = min + (max - min) * rand.nextDouble();
        double temperature = 1000;
        double refroidissement = 0.95;

        while (temperature > 0.1) {
            double voisin = x + (rand.nextDouble() - 0.5);
            if (voisin < min || voisin > max) continue;

            double delta = f(voisin) - f(x);
            if (delta > 0 || Math.exp(delta / temperature) > rand.nextDouble()) {
                x = voisin;
            }

            temperature *= refroidissement;
        }

        return x;
    }
}
