package com.example.appinterface;

import java.io.*;
import java.util.*;

public class TSP {

    private int[][] distanceMatrix;

    public static int[] recuitSimule(double[][] distances) {
        int n = distances.length;
        int[] chemin = new int[n];
        for (int i = 0; i < n; i++) chemin[i] = i;

        Random rand = new Random();
        double temperature = 1000;
        double refroidissement = 0.95;

        while (temperature > 1) {
            int[] voisin = chemin.clone();
            int i = rand.nextInt(n), j = rand.nextInt(n);
            int temp = voisin[i];
            voisin[i] = voisin[j];
            voisin[j] = temp;

            double delta = distanceTotale(voisin, distances) - distanceTotale(chemin, distances);
            if (delta < 0 || Math.exp(-delta / temperature) > rand.nextDouble()) {
                chemin = voisin;
            }

            temperature *= refroidissement;
        }

        return chemin;
    }

    private static double distanceTotale(int[] chemin, double[][] distances) {
        double total = 0;
        for (int i = 0; i < chemin.length - 1; i++) {
            total += distances[chemin[i]][chemin[i + 1]];
        }
        total += distances[chemin[chemin.length - 1]][chemin[0]];
        return total;
    }

    public void loadDistanceMatrix(File file) throws IOException {
        List<int[]> matrixList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] tokens = line.trim().split("\\s+");
            int[] row = new int[tokens.length];
            for (int i = 0; i < tokens.length; i++) {
                row[i] = Integer.parseInt(tokens[i]);
            }
            matrixList.add(row);
        }
        reader.close();

        int n = matrixList.size();
        distanceMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            distanceMatrix[i] = matrixList.get(i);
        }
    }

    public int[][] getDistanceMatrix() {
        return distanceMatrix;
    }

    public double[][] getDistanceMatrixAsDouble() {
        int n = distanceMatrix.length;
        double[][] d = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                d[i][j] = distanceMatrix[i][j];
        return d;
    }
}
