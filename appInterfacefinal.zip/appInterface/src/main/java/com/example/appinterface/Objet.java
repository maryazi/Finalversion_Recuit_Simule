package com.example.appinterface;

public class Objet {
    private int poids;
    private int valeur;

    public Objet(int poids, int valeur) {
        this.poids = poids;
        this.valeur = valeur;
    }

    public int getPoids() {
        return poids;
    }

    public int getValeur() {
        return valeur;
    }
}
